from django.db import migrations


SAMPLE_EXPENSES = [
    {
        "title": "Grocery Shopping",
        "amount": "1450.00",
        "category": "Groceries",
        "expense_date": "2026-09-02",
        "payment_method": "UPI",
        "description": "Weekly groceries from the supermarket.",
    },
    {
        "title": "Bus Pass Recharge",
        "amount": "600.00",
        "category": "Transport",
        "expense_date": "2026-09-03",
        "payment_method": "Cash",
        "description": "Monthly college bus pass.",
    },
    {
        "title": "Mobile Recharge",
        "amount": "299.00",
        "category": "Bills",
        "expense_date": "2026-09-04",
        "payment_method": "UPI",
        "description": "Prepaid mobile recharge plan.",
    },
    {
        "title": "Movie Night",
        "amount": "550.00",
        "category": "Entertainment",
        "expense_date": "2026-09-05",
        "payment_method": "Card",
        "description": "Weekend movie with friends.",
    },
    {
        "title": "Course Textbooks",
        "amount": "1200.00",
        "category": "Education",
        "expense_date": "2026-09-06",
        "payment_method": "Card",
        "description": "Semester reference books.",
    },
    {
        "title": "Electricity Bill",
        "amount": "980.50",
        "category": "Bills",
        "expense_date": "2026-09-08",
        "payment_method": "Net Banking",
        "description": "Monthly electricity bill payment.",
    },
    {
        "title": "Lunch at Canteen",
        "amount": "120.00",
        "category": "Food",
        "expense_date": "2026-09-09",
        "payment_method": "Cash",
        "description": "College canteen lunch.",
    },
    {
        "title": "New Sneakers",
        "amount": "2199.00",
        "category": "Shopping",
        "expense_date": "2026-09-10",
        "payment_method": "Card",
        "description": "Sports shoes for gym.",
    },
]


def load_sample_data(apps, schema_editor):
    Expense = apps.get_model('expenses', 'Expense')
    for item in SAMPLE_EXPENSES:
        # get_or_create prevents duplicate rows if this migration is ever re-run.
        Expense.objects.get_or_create(
            title=item["title"],
            expense_date=item["expense_date"],
            defaults=item,
        )


def remove_sample_data(apps, schema_editor):
    Expense = apps.get_model('expenses', 'Expense')
    titles = [item["title"] for item in SAMPLE_EXPENSES]
    Expense.objects.filter(title__in=titles).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('expenses', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(load_sample_data, remove_sample_data),
    ]
