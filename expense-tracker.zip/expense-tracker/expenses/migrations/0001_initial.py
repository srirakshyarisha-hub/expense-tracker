import django.core.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Expense',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=150)),
                ('amount', models.DecimalField(decimal_places=2, max_digits=10, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('category', models.CharField(choices=[
                    ('Food', 'Food'), ('Transport', 'Transport'), ('Shopping', 'Shopping'),
                    ('Bills', 'Bills'), ('Entertainment', 'Entertainment'), ('Health', 'Health'),
                    ('Education', 'Education'), ('Rent', 'Rent'), ('Groceries', 'Groceries'),
                    ('Other', 'Other'),
                ], max_length=20)),
                ('expense_date', models.DateField()),
                ('payment_method', models.CharField(choices=[
                    ('Cash', 'Cash'), ('Card', 'Card'), ('UPI', 'UPI'),
                    ('Net Banking', 'Net Banking'), ('Other', 'Other'),
                ], max_length=20)),
                ('description', models.TextField(blank=True, default='')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'ordering': ['-expense_date', '-created_at'],
            },
        ),
    ]
